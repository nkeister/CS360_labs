#include "stdio.h"

int main()
{
    printf("t.c test file 1\n");
    printf("t.c test file 2\n");
    printf("t.c test file 3\n");
    printf("t.c test file 4\n");
    /*
        t.c test file for LAB3
                -
                -
                -
                -
        CS360 WSU FALL 2020
    */
    return 0;
}
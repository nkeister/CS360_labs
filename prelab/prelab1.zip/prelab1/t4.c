//********** t2.c file ************
          #include <stdio.h>
	int g[10000] = {4};          
	int main()                              
          {                                   
             int a,b,c; 
             a = 1; b = 2; 
             c = a + b;
             printf("c=%d\n", c);
          }     
